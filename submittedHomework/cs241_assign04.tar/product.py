class Product:
    #Initializes to the values that were passed
    def __init__(self, id, name, price, quantity):
        self.id = id
        self.name = name
        self.price = price
        self.quantity = quantity

    def get_total_price(self):
        #Returns the price multiplied by the quantity
        return self.price * self.quantity
    
    def display(self):
        #Displays the products name, quantity, and total price in the following format:
        print("{} ({}) - ${:.2f}".format(self.name, self.quantity, self.get_total_price()))
