from product import Product
class Order:

    def __init__(self):
        #Initializes to id="", and products to an empty list []
        self.id = ""
        self.products = [] #Product[]

    def get_subtotal(self):
        #Sums the price of each product and returns it
        subtotal = 0.0
        for product in self.products:
            subtotal += product.get_total_price()
        return subtotal

    def get_tax(self):
        #Returns 6.5% times the subtotal
        return self.get_subtotal() * 0.065
        
    def get_total(self):
        #Returns the subtotal plus the tax
        return self.get_subtotal() + self.get_tax()
       
    def add_product(self, product):
        #Adds the provided product to the list - from Product
        self.products.append(product)

    def display_receipt(self):
        #Displays a receipt in the format:
        print("Order: {}".format(self.id))
        for line_item in self.products:
            line_item.display()
        print("Subtotal: ${:.2f}".format(self.get_subtotal()))
        print("Tax: ${:.2f}".format(self.get_tax()))
        print("Total: ${:.2f}".format(self.get_total()))
